from setuptools import setup

setup(
 name='test_py_module',
 version='0.1',
 description='test module',
 url='https://github.com/grzegorzme/test_py_module',
 author='Grzegorz Melniczak',
 author_email='',
 license='MIT',
 packages=['test_py_module'],
 zip_safe=False
)

      
